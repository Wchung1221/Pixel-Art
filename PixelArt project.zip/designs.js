const color = document.getElementById('colorPicker');
const grid = document.getElementById('pixelCanvas');
const height = document.getElementById('inputHeight');
const width = document.getElementById('inputWidth');
const sizePicker = document.getElementById('sizePicker');

sizePicker.onsubmit = function(event) {
  //runs makeGrid when the 'submit' button is pressed
  event.preventDefault();
  grid.style.backgroundColor = null;  //resets background color
  grid.innerHTML = "";  //resets the grid
  makeGrid();
}

function makeGrid() {
  for (var i = 0; i < height.value; i++) {  //creates rows
    var row = grid.insertRow(i);
    for (var j = 0; j < width.value; j++) { //creates cells for each row
      var cell = row.insertCell(j);
      //whenever a cell is clicked, it sets the background color attribute to
      //the selected color
      cell.addEventListener('click', function(event) {
        this.setAttribute("style", 'background-color: '+color.value);
      });
    }
  }
}
